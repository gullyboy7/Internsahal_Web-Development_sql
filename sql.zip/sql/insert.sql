INSERT INTO items(id, name, price)
VALUES
    (1, 'Canon EOS',36000),
    (2, 'Nikon DSLR',40000),
    (3, 'Sony DSLR', 45000),
    (4, 'Olympus DSLR', 50000),
    (5, 'Titan Model #301', 13000),
    (6, 'Titan Model #201', 3000),
    (7, 'HMT Milan', 8000),
    (8, 'Faber Luba #111', 18000),
    (9, 'H&W', 800),
    (10, 'Luis Phil', 1000),
    (11, 'John Zok', 1500),
    (12, 'Jhalsani', 1300);